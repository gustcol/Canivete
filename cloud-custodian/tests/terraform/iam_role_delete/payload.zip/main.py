

def handler(event, ctx):
    print('hello world')
